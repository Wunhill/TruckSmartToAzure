﻿configuration TruckSmartServerInstall
{
    Import-DscResource -ModuleName xWebAdministration
    node "localhost"
    {
        WindowsFeature IIS
        {
            Ensure = "Present"
            Name = "Web-Server"
        }
        WindowsFeature ASP
        {
            Ensure = "Present"
            Name = "Web-Asp-Net45"
        }
               xWebsite DefaultSite 
        {
            Ensure          = 'Present'
            Name            = 'Default Web Site'
            State           = 'Started'
            PhysicalPath    = 'C:\inetpub\wwwroot'
            DependsOn       = '[WindowsFeature]IIS'
        }

        # Copy the website content
        File WebContent
        {
            Ensure          = 'Present'
            SourcePath      = $PSScriptRoot + '\Deploy'
            DestinationPath = 'C:\inetpub\wwwroot'
            Recurse         = $true
            Type            = 'Directory'
            DependsOn       = '[WindowsFeature]ASP'
        }       

    }

}